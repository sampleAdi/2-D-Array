// let ele = document.querySelector('.bar');
// ele.onclick = function () {
//     let mn = document.querySelector('.shrink');
//     let icon=document.querySelector('.fa-bars');
//     mn.classList.toggle('mn');
//     icon.classList.toggle('fa-xmark');   
// }
